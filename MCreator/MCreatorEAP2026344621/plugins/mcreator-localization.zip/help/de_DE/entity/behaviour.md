Lebende Entität, die auf Mob gestellt gesetzt wird, wird in der Lage sein anzugreifen, während eine lebende Entität, die auf Kreatur gesetzt wird, passiv ist.

Ein Raider ist ein Monster, das bei einem Überfall erzeugt wird.

Dieser Parameter wird bei Verwendung von der KI-Basis überschrieben.

Wenn du hier Kreaturentyp auswählst, musst du KI-Typen angreifen, um das Spiel in den meisten Fällen abstürzen zu lassen.