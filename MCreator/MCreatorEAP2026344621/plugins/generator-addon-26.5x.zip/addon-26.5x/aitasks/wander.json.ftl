"minecraft:movement.basic": {
},