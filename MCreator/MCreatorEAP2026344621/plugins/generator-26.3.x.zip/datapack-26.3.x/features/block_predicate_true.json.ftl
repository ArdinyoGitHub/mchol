{
  "type": "minecraft:true"
}