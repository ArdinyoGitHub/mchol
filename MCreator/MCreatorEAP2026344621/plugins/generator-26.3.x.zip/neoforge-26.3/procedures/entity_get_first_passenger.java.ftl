(${input$entity}.getFirstPassenger())
